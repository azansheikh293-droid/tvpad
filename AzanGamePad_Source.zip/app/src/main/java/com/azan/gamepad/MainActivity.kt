package com.azan.gamepad

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.util.concurrent.Executor

class MainActivity : Activity() {
    private var hid: BluetoothHidDevice? = null
    private var adapter: BluetoothAdapter? = null
    private var selected: BluetoothDevice? = null
    private lateinit var status: TextView
    private lateinit var devices: Spinner
    private val pressed = BooleanArray(16)
    private var hat = 0x0F
    private var lx = 0
    private var ly = 0
    private val executor = Executor { it.run() }

    // Standard gamepad report: 16 buttons, hat switch, four 16-bit axes.
    private val descriptor = byteArrayOf(
        0x05,0x01, 0x09,0x05, 0xA1.toByte(),0x01, 0x85.toByte(),0x01,
        0x05,0x09, 0x19,0x01, 0x29,0x10, 0x15,0x00, 0x25,0x01,
        0x95.toByte(),0x10, 0x75,0x01, 0x81.toByte(),0x02,
        0x05,0x01, 0x09,0x39, 0x15,0x00, 0x25,0x07, 0x35,0x00,
        0x46,0x3B,0x01, 0x65,0x14, 0x75,0x04, 0x95.toByte(),0x01, 0x81.toByte(),0x42,
        0x05,0x01, 0x09,0x30, 0x09,0x31, 0x09,0x32, 0x09,0x35,
        0x16,0x00,0x80.toByte(), 0x26,0xFF.toByte(),0x7F, 0x75,0x10, 0x95.toByte(),0x04, 0x81.toByte(),0x02,
        0xC0.toByte()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = BluetoothAdapter.getDefaultAdapter()
        buildUi()
        if (adapter == null) status.text = "Bluetooth not available on this phone"
        else if (!adapter!!.isEnabled) status.text = "Turn on Bluetooth, then tap Refresh"
        else openHidProfile()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(0xFF101522.toInt())
        }
        status = TextView(this).apply {
            text = "Azan GamePad • Pair your TV in Android TV Bluetooth settings first"
            setTextColor(0xFFFFFFFF.toInt()); textSize = 14f
        }
        root.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        devices = Spinner(this)
        row.addView(devices, LinearLayout.LayoutParams(0, 52, 1f))
        row.addView(makeButton("Refresh") { refreshDevices() })
        row.addView(makeButton("Connect") { connectSelected() })
        root.addView(row)

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 2f }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, 0, 1f).apply { height = 0; weight = 1f } }
        val dpadRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        dpadRow.addView(holdButton("◀", 0) { setHat(6) })
        dpadRow.addView(holdButton("▲", 1) { setHat(0) })
        dpadRow.addView(holdButton("▼", 2) { setHat(4) })
        dpadRow.addView(holdButton("▶", 3) { setHat(2) })
        left.addView(dpadRow)
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, 0, 1f).apply { height = 0; weight = 1f } }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER }
        top.addView(holdButton("Y", 3))
        top.addView(holdButton("X", 2))
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottom.addView(holdButton("B", 1))
        bottom.addView(holdButton("A", 0))
        right.addView(top); right.addView(bottom)
        controls.addView(left); controls.addView(right)
        root.addView(controls, LinearLayout.LayoutParams(-1, 0, 1f))

        val shoulders = LinearLayout(this).apply { gravity = Gravity.CENTER }
        shoulders.addView(holdButton("L1", 4)); shoulders.addView(holdButton("L2", 6))
        shoulders.addView(holdButton("R1", 5)); shoulders.addView(holdButton("R2", 7))
        shoulders.addView(holdButton("SELECT", 8)); shoulders.addView(holdButton("START", 9))
        root.addView(shoulders)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun holdButton(label: String, index: Int, onDown: (() -> Unit)? = null): Button {
        return Button(this).apply {
            text = label
            minWidth = 68
            minHeight = 58
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { pressed[index] = true; onDown?.invoke(); sendReport(); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        pressed[index] = false
                        if (onDown != null) hat = 0x0F
                        sendReport(); true
                    }
                    else -> true
                }
            }
        }
    }

    private fun openHidProfile() {
        adapter?.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile != BluetoothProfile.HID_DEVICE) return
                hid = proxy as BluetoothHidDevice
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Azan GamePad", "Phone game controller", "Azan", BluetoothHidDevice.SUBCLASS1_GAMEPAD, descriptor
                )
                val ok = hid?.registerApp(sdp, null, null, executor, object : BluetoothHidDevice.Callback() {
                    override fun onAppStatusChanged(device: BluetoothDevice?, registered: Boolean) {
                        runOnUiThread { status.text = if (registered) "Gamepad ready • Select your paired Akira TV" else "HID registration failed on this phone" }
                        refreshDevices()
                    }
                    override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
                        runOnUiThread { status.text = when (state) {
                            BluetoothProfile.STATE_CONNECTED -> "Connected to ${device?.name ?: "TV"} • Play!"
                            BluetoothProfile.STATE_CONNECTING -> "Connecting…"
                            BluetoothProfile.STATE_DISCONNECTED -> "Disconnected"
                            else -> "Bluetooth state: $state"
                        } }
                    }
                })
                if (ok != true) status.text = "Could not register Bluetooth gamepad. Phone firmware may not support HID Device."
            }
            override fun onServiceDisconnected(profile: Int) { hid = null }
        }, BluetoothProfile.HID_DEVICE)
    }

    private fun refreshDevices() {
        val bonded = adapter?.bondedDevices?.toList().orEmpty()
        val labels = bonded.map { "${it.name ?: "Bluetooth device"}  (${it.address})" }
        devices.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        status.text = if (bonded.isEmpty()) "No paired devices. Pair Akira TV in Bluetooth settings first." else "Choose your Akira TV, then tap Connect."
    }

    private fun connectSelected() {
        val bonded = adapter?.bondedDevices?.toList().orEmpty()
        val index = devices.selectedItemPosition
        if (index !in bonded.indices) { status.text = "Pair the TV first, then Refresh."; return }
        selected = bonded[index]
        val ok = hid?.connect(selected!!)
        status.text = if (ok == true) "Connecting to ${selected?.name}…" else "Connect failed. Check TV pairing and HID support."
    }

    private fun setHat(value: Int) { hat = value; sendReport() }

    private fun sendReport() {
        val device = selected ?: return
        val service = hid ?: return
        val bytes = ByteArray(11)
        for (i in 0 until 16) if (pressed[i]) bytes[i / 8] = (bytes[i / 8].toInt() or (1 shl (i % 8))).toByte()
        bytes[2] = hat.toByte()
        put16(bytes, 3, lx); put16(bytes, 5, ly); put16(bytes, 7, 0); put16(bytes, 9, 0)
        service.sendReport(device, 1, bytes)
    }

    private fun put16(out: ByteArray, offset: Int, value: Int) {
        out[offset] = (value and 0xFF).toByte()
        out[offset + 1] = ((value shr 8) and 0xFF).toByte()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid) } catch (_: Exception) {}
    }
}
