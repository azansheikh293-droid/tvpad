# Azan GamePad (prototype source)

This is an Android Studio starter project for the **phone-side Bluetooth HID gamepad**.

## Important compatibility notes
- Target TV: Akira Android TV 9.
- Phone: Vivo Y20 (exact Android build varies by region).
- The app tries to register the phone as a Bluetooth HID gamepad. This depends on the phone's Android firmware exposing `BluetoothHidDevice`; some manufacturers disable or restrict it.
- Pair the phone from the TV's Bluetooth settings first. Then open this app, tap Refresh, select the TV, and tap Connect.
- If HID registration fails, this prototype cannot control the TV over Bluetooth. A Wi-Fi receiver would require a separate TV-side APK and a supported input-injection method; it is not included in this prototype.
- The current prototype has face buttons, D-pad and shoulder buttons. Analog joystick UI and Wi-Fi fallback are not implemented yet.

## Build
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync. Use JDK 17.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on the Vivo Y20.

This is source code, not a prebuilt APK. Test with a game that supports standard Bluetooth gamepads.
